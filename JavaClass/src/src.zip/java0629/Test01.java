package java0629;

public class Test01 {
	
//	System.out.print("Hello World");
	
}
